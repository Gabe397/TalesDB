<?php
error_reporting(E_ALL | E_WARNING | E_NOTICE);
ini_set('display_errors', TRUE);

include '/home/serafim447/ip.php';

session_start();
if (isset($_SESSION['user'])) {
  //Let it run
} else {
  header("Location: login.html");
}

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
$connection = new AMQPStreamConnection($ip, 5672, 'gabe', 'gabe');
$channel = $connection->channel();
$result = ($channel->basic_get('friendsReply',true,null)->body);

$result_array = preg_split ("/\,/", $result);
$noQuote = array((count($result_array)-1)=> rtrim(end($result_array), '"'));
$followProfile = array_replace($result_array, $noQuote);

$channel->close();
$connection->close();
?>

<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="dark.css">

    <script>
    function showFollowing(){
    var followerInfo = <?php echo json_encode($followProfile); ?>;
    console.log(followerInfo[1]);
    document.getElementById('userName').innerHTML += followerInfo[1]+ " " +followerInfo[2];
    document.getElementById('zip').innerHTML += followerInfo[3];
      for (var indexDrink = 4; indexDrink < followerInfo.length; indexDrink+=4) {
        document.getElementById('friendFav').innerHTML += followerInfo[indexDrink]+ "<br />";
        document.getElementById('friendFav').innerHTML += followerInfo[indexDrink+1]+ "<br />";
        document.getElementById('friendFav').innerHTML += "<button class='btn btn-secondary btn-sm' id='followerBtn' name='emailFriend' value=" +followerInfo[1] + followerInfo[indexDrink]+ ">Email Friend to go out for this drink</button><br /><br />";
        document.getElementById('friendFav').innerHTML += "<img src='" + followerInfo[indexDrink+2] + "' width=25% height=25%> <br />";
        document.getElementById('friendFav').innerHTML += "Rated this drink a: " +followerInfo[indexDrink+3]+ "<br />";
      }
     }
    </script>

</head>

<body onload="showFollowing()">
    <div class="login-dark">
      <form action="friendLoader.php" method="post">
        <div class="illustration"><a href="dashboard.php"><i class="icon ion-ios-locked-outline"></i></a></div>
          <h2><span id="userName"></span></h2>
          <h3>Living within <span id="zip"></span></h3>
          <h4><span id="friendFav"></span></h4>
          <!-- <div class="form-group"><button class="btn btn-primary btn-block" id="btn" name="Dash">Go back to Dashboard</button> -->
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</body>

</html>
