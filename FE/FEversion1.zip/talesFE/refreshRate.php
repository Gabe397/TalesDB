<?php
error_reporting(E_ALL | E_WARNING | E_NOTICE);
ini_set('display_errors', TRUE);

include '/home/serafim447/ip.php';

session_start();
if (isset($_SESSION['user'])) {
  //Let it run
}
 else {
  header("Location: login.html");
}

$email = $_SESSION['user'][0];

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
$connection = new AMQPStreamConnection($ip, 5672, 'gabe', 'gabe');
$channel = $connection->channel();

$channel->queue_declare('profile', false, true, false, false);
$msg = new AMQPMessage("{$_SESSION['user'][0]}");
$channel->basic_publish($msg, '', 'profile');
header("Refresh: 0; url=userPage.php");
?>