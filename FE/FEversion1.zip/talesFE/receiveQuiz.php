<?php
error_reporting(E_ALL | E_WARNING | E_NOTICE);
ini_set('display_errors', TRUE);

include '/home/serafim447/ip.php';

session_start();
if (isset($_SESSION['user'])) {
  //Let it run
} else {
  header("Location: login.html");
}

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
$connection = new AMQPStreamConnection($ip, 5672, 'gabe', 'gabe');
$channel = $connection->channel();
$result = ($channel->basic_get('alcoholicReply',true,null)->body);

$result_array = preg_split ("/\,/", $result);
$noQuote = array((count($result_array)-1)=> rtrim(end($result_array), '"'));
$drinks = array_replace($result_array, $noQuote);

?>

<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="dark.css">

    <script>
  function showDrinks(){
  var drinks = <?php echo json_encode($drinks); ?>;
  var session = <?php echo json_encode($_SESSION['user']); ?>;
    for (var indexDrink = 1; indexDrink < drinks.length; indexDrink+=3) {
        document.getElementById('quizDrinks').innerHTML += drinks[indexDrink]+ "<br />";
        document.getElementById('quizDrinks').innerHTML += drinks[indexDrink+1]+ "<br />";
        document.getElementById('quizDrinks').innerHTML += "<input type='radio' name='drinkSelect' value='" +session[0]+"#"+session[2]+"#"+drinks[indexDrink + 1]+"#"+drinks[indexDrink] +"#" + drinks[indexDrink+2] + "'><br /><br />";
        document.getElementById('quizDrinks').innerHTML += "<img src='" + drinks[indexDrink+2] + "' width=25% height=25%> <br /><br/>";
      }
    }
      </script>
      <style>
      .login-dark form {
        max-width: 920px;
        max-height: 3000px !important;
        height: auto;
        width: 90%;
        background-color: #1e2833;
        padding: 40px;
        border-radius: 4px;
        /* transform: translate(-50%, -50%); */
        margin-left: -30%;
        margin-top: -3%;
        position: absolute;
        top: 50%;
        left: 50%;
        color: #fff;
        box-shadow: 3px 3px 4px rgba(0, 0, 0, 0.2);
        }
        .flex-container {
          display: flex;
        }
      </style>
</head>

<body onload="showDrinks()">
    <div class="login-dark flex-container">
        <form action="addToFaves.php" method="post">
            <h3>Drink's List</h3>
            <h5>Click one to add to your favorites list</h5>
            <div class="illustration"><a href="dashboard.php"><i class="icon ion-ios-locked-outline"></i></a></div>
            <p><span id="quizDrinks"></p>
            <div class="form-group"><button class="btn btn-primary btn-block" id="btn" name="Submit">Submit</button>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>

</body>

</html>
