<?php
error_reporting(E_ALL | E_WARNING | E_NOTICE);
ini_set('display_errors', TRUE);

session_start();
if (isset($_SESSION['user'])) {
  //Print out the Session array
  // foreach($_SESSION['user'] as $productId){
  //       echo $productId, '<br>';
  //     }
} else {
  header("Location: login.html");
}

if($_POST['emailFriend']){
  $emailTo = $_POST['emailFriend'];
  $pieces = preg_split('/(?=[A-Z])/',$emailTo);
  $last_word = $pieces[2];
  $first_word = $pieces[1];

  require 'PHPMailer/PHPMailerAutoload.php';

  $mail = new PHPMailer;
  //$mail->SMTPDebug = 2;                        // Enable verbose debug output

  $mail->isSMTP();                            // Set mailer to use SMTP
  $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
  $mail->SMTPAuth = true;                     // Enable SMTP authentication
  $mail->Username = 'talesIT490@gmail.com';          // SMTP username
  $mail->Password = 'Snapple88!'; // SMTP password
  $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
  $mail->Port = 587;                          // TCP port to connect to

  $mail->setFrom('tales.com@gmail.com', 'Tales');
  $mail->addReplyTo('tales.com@gmail.com', 'Tales');
  $mail->addAddress('gabe3197@gmail.com');   // Add a recipient
  $mail->addCC('fjp23@njit.edu');
  $mail->addBCC('fjp23@njit.edu');

  $mail->isHTML(true);  // Set email format to HTML

  $bodyContent = "<h1>Hi we're both on Tales lets go out for drinks together </h1>";
  $bodyContent .= "We both favorited $last_word , we should go try it together! ";

  $mail->Subject = "Email from $first_word on Tales ";
  $mail->Body    = $bodyContent;

  if(!$mail->send()) {
      echo 'Message could not be sent.';
      echo 'Mailer Error: ' . $mail->ErrorInfo;
  } else {
      echo 'Message has been sent';
  }
  header("Refresh: 0; url=dashboard.php");
}
if($_POST['Dash']) {
  header("Refresh: 0; url=dashboard.php");
}
?>
