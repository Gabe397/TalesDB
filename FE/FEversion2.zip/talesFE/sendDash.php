<?php

include '/home/serafim447/ip.php';

session_start();
if (isset($_SESSION['user'])) {
  //Let it run
}
 else {
  header("Location: login.html");
}


$date = date("Y-m-d");
$time = date("h:i:sa");

if($_POST['logout']) {
  session_destroy();
  header("Refresh: 4; url=login.html");
}
if($_POST['quiz']) {
  header("Location: talesQuiz.php");
}

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
$connection = new AMQPStreamConnection($ip, 5672, 'gabe', 'gabe');
$channel = $connection->channel();

if($_POST['profile']) {
  $channel->queue_declare('profile', false, true, false, false);
  $msg = new AMQPMessage("{$_SESSION['user'][0]}");
  $channel->basic_publish($msg, '', 'profile');

  $msg2 = new AMQPMessage("{$_SESSION['user'][0]} accessed their profile;{$date} {$time}");
  $channel->queue_declare('logs', false, true, false, false);
  $channel->basic_publish($msg2, '', 'logs');

  echo "Going to profile page";
  header("Refresh: 4; url=userPage.php");
}

if($_POST['planner']) {
  $channel->queue_declare('alcoholic', false, true, false, false);
  $msg = new AMQPMessage("{$_SESSION['user'][3]}");
  $channel->basic_publish($msg, '', 'alcoholic');

  $msg2 = new AMQPMessage("{$_SESSION['user'][0]} is planning their night;{$date} {$time}");
  $channel->queue_declare('logs', false, true, false, false);
  $channel->basic_publish($msg2, '', 'logs');

  echo " [x] Sent {$_SESSION['user'][3]}\n";
  header("Refresh: 4; url=showPlan.php");
}

if($_POST['pop']) {
  $channel->queue_declare('popular', false, true, false, false);
  $msg = new AMQPMessage("{$_SESSION['user'][3]}");
  $channel->basic_publish($msg, '', 'popular');

  $msg2 = new AMQPMessage("{$_SESSION['user'][0]} is viewing popular drinks;{$date} {$time}");
  $channel->queue_declare('logs', false, true, false, false);
  $channel->basic_publish($msg2, '', 'logs');

  echo " [x] Sent {$_SESSION['user'][3]}\n";
  header("Refresh: 4; url=showPop.php");
}

$channel->close();
$connection->close();
?>
<!DOCTYPE html>
<html>
<head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<link type="text/css" rel="stylesheet" href="style.css" />
<link href='https://fonts.googleapis.com/css?family=Lato:300,400' rel='stylesheet' type='text/css'/>
</head>
<body>
<div id="loader">
    <div id="lemon"></div>
    <div id="straw"></div>
    <div id="glass">
        <div id="cubes">
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div id="drink"></div>
        <span id="counter"></span>
    </div>
    <div id="coaster"></div>
</div>

<footer>Please wait..</footer>



<script>
var worker = null;
var loaded = 0;

function increment() {
    $('#counter').html(loaded+'%');
    $('#drink').css('top', (100-loaded*.9)+'%');
    if(loaded==25) $('#cubes div:nth-child(1)').fadeIn(100);
    if(loaded==50) $('#cubes div:nth-child(2)').fadeIn(100);
    if(loaded==75) $('#cubes div:nth-child(3)').fadeIn(100);
    if(loaded==100) {
        $('#lemon').fadeIn(100);
        $('#straw').fadeIn(300);
        loaded = 0;
        stopLoading();
        setTimeout(startLoading, 1000);
    }
    else loaded++;
}

function startLoading() {
    $('#lemon').hide();
    $('#straw').hide();
    $('#cubes div').hide();
    worker = setInterval(increment, 30);
}
function stopLoading() {
    clearInterval(worker);
}

startLoading();
</script>
</body>
</html>
