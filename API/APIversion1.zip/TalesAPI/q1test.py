import APIFunctions2

#APIFunctions2.alcoholic("alchoholic")
#APIFunctions2.category("alcoholic","Cocktail")
#APIFunctions2.logs("Quiz results returned ")
#APIFunctions2.ingrediants("nonalcoholic","Cocoa","milk")
APIFunctions2.planmynight("07002")
#APIFunctions.popular_drinks()
#APIFunctions.howtomake("11007")

#print(type(['Correct Array', u'178314', u'Gin Basil Smash', u'https://www.thecocktaildb.com/images/media/drink/jqh2141572807327.jpg', u'178315', u'Munich Mule', None]))