import datetime 

now = datetime.datetime.now()

#timestamp = datetime.datetime(now)
print("test"+":"+ str(now))