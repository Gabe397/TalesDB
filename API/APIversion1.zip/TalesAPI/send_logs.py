import pika
import APIFunctions2
import json
import sys

sys.path.insert(1,'/home/serafim447/')

import rmqIP

credentials = pika.PlainCredentials('gabe','gabe')
connection = pika.BlockingConnection(pika.ConnectionParameters(rmqIP.franklin(),5672,'/',credentials))

channel = connection.channel()

channel.queue_declare(queue='logs',passive=False,durable=True)

def callback(ch, method, properties, body): 
    var = APIFunctions2.logs(body)
    channel.basic_publish(exchange='',
        			 routing_key='logs',
        			 body=json.dumps(var))
    print("Message Sent")
 

channel.start_consuming()
connection.close() 
