import pika
import APIFunctions2
import json
import datetime
import sys

sys.path.insert(1,'/home/serafim447/')

import rmqIP

credentials = pika.PlainCredentials('gabe','gabe')
connection = pika.BlockingConnection(pika.ConnectionParameters(rmqIP.franklin(),5672,'/',credentials))

channel = connection.channel()

channel.queue_declare(queue='quiz',passive=False,durable=True)

def callback(ch, method, properties, body):
	args = body.split(":") 
	var = APIFunctions2.ingrediants(args[0],args[1],args[2])
	final = [] 
	emptyStr = ''
	for word in var:
		final.append(word.encode('utf8'))
	final = ','.join(final)
	channel.basic_publish(exchange='',
        			 routing_key='alcoholicReply',
        			 body=json.dumps(final)) 
	channel.basic_publish(exchange='',
        			 routing_key='logs',
        			 body="popular_drinks returned" + ";" + str(datetime.datetime.now()))
	print("Message Sent:")
	print(final)



channel.basic_consume(
	queue='quiz',  
    on_message_callback=callback,
    auto_ack=True)

print ( '[*] Waiting for messages. To exit press CTRL+C')



channel.start_consuming()
connection.close() 
